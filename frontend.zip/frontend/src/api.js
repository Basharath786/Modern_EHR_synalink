const KEY = "cobalt.session";

export const session = {
  get: () => { try { return JSON.parse(sessionStorage.getItem(KEY)); } catch { return null; } },
  set: (s) => sessionStorage.setItem(KEY, JSON.stringify(s)),
  clear: () => sessionStorage.removeItem(KEY),
};

export async function api(path, { method = "GET", body } = {}) {
  const s = session.get();
  const res = await fetch(`/api/v1/${path}`, {
    method,
    headers: { "Content-Type": "application/json", ...(s?.token ? { Authorization: `Bearer ${s.token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }
  if (res.status === 401 && s?.token && !path.startsWith("auth/login")) {
    session.clear();
    window.location.href = "/login?reason=session";
  }
  return { ok: res.ok, status: res.status, data };
}
