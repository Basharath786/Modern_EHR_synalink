import { Link } from "react-router-dom";
import { useAuth } from "../auth";
import { PORTALS } from "../roles";
import { slug } from "../components/Shell";

const PHASES = [["Foundation & login", true], ["Patient", false], ["Doctor + Reception", false], ["Hospital + Admins", false], ["Lab + Pharmacy", false], ["Integrations", false]];

export default function Home() {
  const { user } = useAuth();
  const portal = PORTALS[user.portal];
  const hour = new Date().getHours();
  const greet = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  const last = user.last_login ? new Date(user.last_login).toLocaleString() : "First sign-in";

  return (
    <div className="stack">
      <section className="hero-card">
        <div>
          <p className="eyebrow">{greet}</p>
          <h1>{user.name}</h1>
          <p className="muted">Signed in to the {portal.title}</p>
        </div>
        <dl className="facts">
          <div><dt>User ID</dt><dd>{user.permanentid}</dd></div>
          <div><dt>Role</dt><dd>{user.role.replace("_", " ")}</dd></div>
          <div><dt>Previous login</dt><dd>{last}</dd></div>
        </dl>
      </section>

      <section className="card">
        <div className="card-head"><h3>Conversion progress</h3><span className="pill">Phase 1 of 6 complete</span></div>
        <ol className="steps">
          {PHASES.map(([name, done], i) => (
            <li key={name} className={done ? "done" : ""}><span>{done ? "✓" : i + 1}</span>{name}</li>
          ))}
        </ol>
      </section>

      <section>
        <h3 className="section-title">Your modules</h3>
        <div className="grid">
          {portal.modules.map(([name, phase]) => (
            <Link key={name} to={`/app/${slug(name)}`} state={{ name, phase }} className="module-card">
              <b>{name}</b><span>Arrives in Phase {phase}</span>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
