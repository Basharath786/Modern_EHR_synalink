// Sidebar modules per portal. `phase` = which conversion phase brings it live.
export const PORTALS = {
  patient: { title: "Patient Portal", modules: [["Appointments", 2], ["Medical Reports", 2], ["Vaccinations", 2], ["Allergies", 2], ["Notifications", 2]] },
  doctor: { title: "Doctor Portal", modules: [["Today's Appointments", 3], ["Patient Records", 3], ["Prescriptions", 3], ["Lab Orders", 3], ["Referrals", 3]] },
  reception: { title: "Reception", modules: [["Book Appointment", 3], ["Patient Check-in", 3], ["Doctor Slots", 3]] },
  hospital: { title: "Hospital Portal", modules: [["Departments", 4], ["Doctors", 4], ["Receptionists", 4], ["Affiliations", 4]] },
  "internal-admin": { title: "Internal Admin", modules: [["Approvals", 4], ["Registered Users", 4], ["Reports", 4]] },
  lab: { title: "Lab Portal", modules: [["Lab Orders", 5], ["Lab Staff", 5], ["Reports Upload", 5]] },
  "lab-staff": { title: "Lab Staff", modules: [["Assigned Orders", 5], ["Upload Reports", 5]] },
  pharmacy: { title: "Pharmacy Portal", modules: [["Medicine Orders", 5], ["Pharmacy Staff", 5], ["Inventory", 5]] },
  "pharmacy-staff": { title: "Pharmacy Staff", modules: [["Assigned Orders", 5], ["Dispense", 5]] },
};

export const STATUS_MESSAGES = {
  id_error: "We couldn't find that ID. Check it and try again.",
  password_error: "Incorrect password. 3 wrong attempts lock the account for 2 minutes.",
  locked_account: "Account temporarily locked. Please try again after 2 minutes.",
  password_expired: "Your password has expired. Please reset it to continue.",
  temp_password_expired: "Your temporary password has expired. Please request a new one.",
  missing_fields: "Enter both your ID and password.",
};
