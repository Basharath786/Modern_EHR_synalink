import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./auth";
import Login from "./pages/Login";
import ChangePassword from "./pages/ChangePassword";
import Shell from "./components/Shell";
import Home from "./pages/Home";
import ComingSoon from "./pages/ComingSoon";

function Protected({ children }) {
  const { session, isTemp } = useAuth();
  if (!session) return <Navigate to="/login" replace />;
  if (isTemp) return <Navigate to="/change-password" replace />;
  return children;
}

export default function App() {
  const { session } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={session && !session.scope?.startsWith("change") ? <Navigate to="/app" replace /> : <Login />} />
      <Route path="/change-password" element={session ? <ChangePassword /> : <Navigate to="/login" replace />} />
      <Route path="/app" element={<Protected><Shell /></Protected>}>
        <Route index element={<Home />} />
        <Route path=":module" element={<ComingSoon />} />
      </Route>
      <Route path="*" element={<Navigate to="/app" replace />} />
    </Routes>
  );
}
