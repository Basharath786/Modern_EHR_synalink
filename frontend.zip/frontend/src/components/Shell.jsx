import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../auth";
import { PORTALS } from "../roles";
import { Grid, Key, Logout, Pulse } from "./Icons";
import ThemeToggle from "./ThemeToggle";

export const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

export default function Shell() {
  const { user, signOut } = useAuth();
  const nav = useNavigate();
  const portal = PORTALS[user.portal];
  const initials = (user.name || user.permanentid).split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark"><Pulse /></span><div><b>Cobalt</b><small>{portal.title}</small></div></div>
        <nav>
          <NavLink to="/app" end className="nav-item"><Grid /> Dashboard</NavLink>
          <p className="nav-label">Modules</p>
          {portal.modules.map(([name, phase]) => (
            <NavLink key={name} to={`/app/${slug(name)}`} state={{ name, phase }} className="nav-item">
              <span className="nav-dot" /> {name}<em className="phase-tag">P{phase}</em>
            </NavLink>
          ))}
          <p className="nav-label">Account</p>
          <button className="nav-item" onClick={() => nav("/change-password")}><Key /> Change password</button>
        </nav>
      </aside>
      <div className="main">
        <header className="topbar">
          <div><h2>{portal.title}</h2></div>
          <div className="topbar-right">
            <ThemeToggle />
            <div className="avatar" title={user.permanentid}>{initials}</div>
            <button className="btn ghost" onClick={() => { signOut(); nav("/login"); }}><Logout /> Sign out</button>
          </div>
        </header>
        <main className="content"><Outlet /></main>
      </div>
    </div>
  );
}
